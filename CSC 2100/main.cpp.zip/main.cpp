#include <iostream>
using namespace std;
int main()
{
    cout << "This is my first C++ program." << endl;
    cout << "Hopefully, it will not be my last." << endl;
    return 0;
}